<div class="container">
    <div class="row">
        <div class="col-lg-6 mt-2">
            <h5>About Us</h5>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.</p>
        </div>
        <div class="col-lg-6 mt-2">
            <h5>Contact Us</h5>
            <ul class="list-unstyled">
                <li>Address: 123 Street, City</li>
                <li>Email: info@example.com</li>
                <li>Phone: 123-456-7890</li>
            </ul>
        </div>
    </div>
</div>