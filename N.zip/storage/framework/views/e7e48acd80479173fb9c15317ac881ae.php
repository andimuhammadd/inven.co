<!-- Modal Hapus Satuan -->
<div class="modal fade" id="modalHapus<?php echo e($barangMasuk->id); ?>" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUserModalLabel">Hapus Transaksi Barang Masuk</h5>
                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('barangmasuk.destroy', $barangMasuk->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <div class="mb-3">
                        <label for="nama_barang" class="form-label">ID Transaksi</label>
                        <input type="text" class="form-control" value="<?php echo e($barangMasuk->id); ?>" id="nama_barang" name="nama_barang" required readonly>
                    </div>

                    <div class="mb-3">
                        <label for="nama_barang" class="form-label">Kode Barang</label>
                        <input type="text" class="form-control" id="nama_barang" value="<?php echo e($barangMasuk->databarang->kode_barang); ?>" name="nama_barang" required readonly>
                    </div>

                    <div class="mb-3">
                        <label for="nama_barang" class="form-label">Nama Barang</label>
                        <input type="text" class="form-control" id="nama_barang" name="nama_barang" value="<?php echo e($barangMasuk->databarang->nama); ?>" required readonly>
                    </div>

                    <div class="mb-3">
                        <label for="jumlah" class="form-label">Jumlah</label>
                        <input type="number" class="form-control" id="jumlah" name="jumlah" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Hapus Satuan</button>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\inven\resources\views/component/barangmasuk/modal_hapus2.blade.php ENDPATH**/ ?>