<div class="col">
    <div class="table-responsive">
        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th scope="col">Nomor</th>
                    <th scope="col">Kode Barang</th>
                    <th scope="col">Nama Barang</th>
                    <th scope="col">Jenis Barang</th>
                    <th scope="col">Jumlah</th>
                    <th scope="col">Satuan</th>
                    <th scope="col">Supplier</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $number = 1;
                ?>
                <?php $__currentLoopData = $databarangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $databarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($number); ?></td>
                    <td><?php echo e($databarang->kode_barang); ?></td>
                    <td><?php echo e($databarang->nama_barang); ?></td>
                    <td><?php echo e($databarang->jenis->nama); ?></td>
                    <td><?php echo e($databarang->jumlah ?? 0); ?></td>
                    <td><?php echo e($databarang->satuan->nama_satuan); ?></td>
                    <td><?php echo e($databarang->supplier->nama); ?></td>
                    <td>

                        <?php echo $__env->make('component.databarang.modalhapus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#modalHapus<?php echo e($databarang->id); ?>">Hapus</a>
                    </td>
                </tr>
                <?php
                $number++;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(count($databarangs) === 0): ?>
                <tr>
                    <td colspan="5">Data Barang kosong</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Button trigger modal -->
    <button id="btnModal" type="button" class="btn btn-primary">Tambah Data Barang</button>

    <!-- Modal -->
    <?php echo $__env->make('component.databarang.templateModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Modal -->

    <!-- Include jQuery library -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#btnModal').click(function() {
                // Menggunakan AJAX untuk memuat konten modal
                $.ajax({
                    url: "<?php echo e(route('databarang.create')); ?>",
                    method: "GET",
                    dataType: "html",
                    success: function(response) {
                        $('#modalContent').html(response);

                        // Menampilkan modal setelah konten dimuat
                        var modal = new bootstrap.Modal(document.getElementById('modalAddDataBarang'));
                        modal.show();
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                    }
                });
            });
        });
    </script>

</div><?php /**PATH D:\laragon\www\inven\resources\views/pages/databarang.blade.php ENDPATH**/ ?>