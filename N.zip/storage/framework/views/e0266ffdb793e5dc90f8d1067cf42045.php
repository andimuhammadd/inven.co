<div id="modalContent">
    <form action="<?php echo e(route('databarang.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="kode_barang" class="form-label">Kode Barang</label>
            <input type="text" class="form-control" id="kode_barang" name="kode_barang" value="<?php echo e($kode_barang); ?>" required readonly>
        </div>

        <div class="mb-3">
            <label for="nama_barang" class="form-label">Nama Barang</label>
            <input type="text" class="form-control" id="nama_barang" name="nama_barang" required>
        </div>

        <div class="mb-3">
            <label for="jenis_barang" class="form-label">Jenis Barang</label>
            <div class="input-group">
                <select class="form-control" id="jenis_barang" name="jenis_barang" required>
                    <option value="" disabled selected>Pilih Jenis Barang</option>
                    <?php if($jenisbarangs->isEmpty()): ?>
                    <option value="" disabled>Data Jenis Barang tidak ada</option>
                    <?php else: ?>
                    <?php $__currentLoopData = $jenisbarangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenisbarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($jenisbarang->id); ?>"><?php echo e($jenisbarang->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <div class="input-group-append">
                    <span class="input-group-text"><i class="bi bi-caret-down-fill"></i></span>
                </div>
            </div>
        </div>

        <div class="mb-3">
            <label for="satuan_barang" class="form-label">Satuan Barang</label>
            <div class="input-group">
                <select class="form-control" id="satuan_barang" name="satuan_barang" required>
                    <option value="" disabled selected>Pilih Satuan Barang</option>
                    <?php if($satuanbarangs->isEmpty()): ?>
                    <option value="" disabled>Data Satuan Barang tidak ada</option>
                    <?php else: ?>
                    <?php $__currentLoopData = $satuanbarangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satuanbarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($satuanbarang->id); ?>"><?php echo e($satuanbarang->nama_satuan); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <div class="input-group-append">
                    <span class="input-group-text"><i class="bi bi-caret-down-fill"></i></span>
                </div>
            </div>
        </div>

        <div class="mb-3">
            <label for="supplier" class="form-label">Supplier</label>
            <div class="input-group">
                <select class="form-control" id="supplier" name="supplier" required>
                    <option value="" disabled selected>Pilih Supplier</option>
                    <?php if($suppliers->isEmpty()): ?>
                    <option value="" disabled>Data supplier tidak ada</option>
                    <?php else: ?>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <div class="input-group-append">
                    <span class="input-group-text"><i class="bi bi-caret-down-fill"></i></span>
                </div>
            </div>
        </div>
        <input type="hidden" name="id_perusahaan" value="<?php echo e(Auth::user()->perusahaan_id); ?>">

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
    </form>
</div><?php /**PATH D:\laragon\www\inven\resources\views/component/databarang/modal_tambah_barang.blade.php ENDPATH**/ ?>