<div class="container-md">
    <a class="navbar-brand" href="#">INVEN.CO</a>
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger">Logout</button>
            </form>
            <?php else: ?>
            <a href="<?php echo e(route('loginpage')); ?>" class="btn btn-success">Login/SignUp</a>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\inven\resources\views/partials/header.blade.php ENDPATH**/ ?>