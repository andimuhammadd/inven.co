<div class="modal fade" id="modalhapus<?php echo e($barangKeluar->id); ?>" tabindex="-1" aria-labelledby="modalhapus<?php echo e($barangKeluar->id); ?>Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modaljual<?php echo e($barangKeluar->id); ?>Label">Hapus Transaksi Barang Keluar</h5>
                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('barangkeluar.destroy')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name" class="form-label">Tanggal Keluar</label>
                        <input type="text" class="form-control" id="name" name="nama" value="<?php echo e($barangKeluar->created_at); ?>" readonly>
                    </div>

                    <div class="mb-3">
                        <label for="name" class="form-label">Nama Produk</label>
                        <input type="text" class="form-control" id="name" name="nama" value="<?php echo e($barangKeluar->databarang->nama_barang); ?>" readonly>
                    </div>

                    <div class="mb-3">
                        <label for="name" class="form-label">Kode Produk</label>
                        <input type="text" class="form-control" id="name" name="nama" value="<?php echo e($barangKeluar->databarang->kode_barang); ?>" readonly>
                    </div>

                    <div class="mb-3">
                        <label for="name" class="form-label">Supplier</label>
                        <input type="text" class="form-control" id="name" name="nama" value="<?php echo e($barangKeluar->databarang->supplier->nama); ?>" readonly>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\inven\resources\views/component/barangkeluar/modal_hapus.blade.php ENDPATH**/ ?>