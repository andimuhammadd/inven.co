<div class="col">
    <div class="table-responsive">
        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th>Nomor</th>
                    <th>Jenis Barang</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $number = 1;
                ?>
                <?php $__currentLoopData = $jenisbarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($number); ?></td>
                    <td><?php echo e($jenis->nama); ?></td>
                    <td>
                        <?php echo $__env->make('component.jenisbarang.modal_edit_jenis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#modaledit<?php echo e($jenis->id); ?>">Edit</a>

                        <?php echo $__env->make('component.jenisbarang.modal_hapus_jenis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#modalhapus<?php echo e($jenis->id); ?>">Hapus</a>
                    </td>
                </tr>
                <?php
                $number++;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(count($jenisbarang) === 0): ?>
                <tr>
                    <td colspan="5">Data Jenis Barang kosong</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo $__env->make('component.jenisbarang.modal_tambah_jenis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAddjenis">
        Tambah Jenis Barang
    </button>
</div><?php /**PATH D:\laragon\www\inven\resources\views/pages/jenisbarang.blade.php ENDPATH**/ ?>