<!-- Modal Hapus Satuan -->
<div class="modal fade" id="modalhapus<?php echo e($jenis->id); ?>" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUserModalLabel">Form Hapus Jenis Barang</h5>
                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('jenisbarang.destroy', $jenis->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <h5 class="modal-title" id="editUserModalLabel">Hapus Jenis Barang <?php echo e($jenis->nama); ?>?</h5>
                    <button type="submit" class="btn btn-primary">Hapus Jenis Barang</button>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\inven\resources\views/component/jenisbarang/modal_hapus_jenis.blade.php ENDPATH**/ ?>