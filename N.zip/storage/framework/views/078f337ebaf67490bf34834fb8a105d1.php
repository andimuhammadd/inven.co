<!-- Modal Hapus -->
<div class="modal fade" id="modalHapus<?php echo e($databarang->id); ?>" tabindex="-1" aria-labelledby="modalHapusLabel<?php echo e($databarang->id); ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalHapusLabel<?php echo e($databarang->id); ?>">Hapus Barang <?php echo e($databarang->kode_barang); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Anda yakin ingin menghapus barang ini?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                <form action="<?php echo e(route('databarang.destroy', $databarang->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\inven\resources\views/component/databarang/modalhapus.blade.php ENDPATH**/ ?>