<div class="modal fade" id="modaljual<?php echo e($barangMasuk->id); ?>" tabindex="-1" aria-labelledby="modaljual<?php echo e($barangMasuk->id); ?>Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modaljual<?php echo e($barangMasuk->id); ?>Label">Jual Barang - <?php echo e($barangMasuk->databarang->nama_barang); ?></h5>
                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('barangkeluar.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id_data_barang" value="<?php echo e($barangMasuk->id_data_barang); ?>">
                    <input type="hidden" name="id_perusahaan" value="<?php echo e(Auth::user()->perusahaan_id); ?>">

                    <div class="mb-3">
                        <label for="jumlah" class="form-label">Masukkan Jumlah Jual</label>
                        <input type="number" class="form-control" id="jumlah" name="jumlah" required>
                    </div>

                    <div class="mb-3">
                        <label for="keterangan" class="form-label">Keterangan</label>
                        <textarea class="form-control" id="keterangan" name="keterangan" rows="3"></textarea>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-success">Jual</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\inven\resources\views/component/barangmasuk/modal_jual_barang.blade.php ENDPATH**/ ?>