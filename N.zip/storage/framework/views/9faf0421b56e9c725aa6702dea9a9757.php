<?php $__env->startSection('pageTitle'); ?>
<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $content; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('cardHeader'); ?>
<?php echo e($cardHeader); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('cardTitle'); ?>
<?php echo e($cardTitle); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\inven\resources\views/main.blade.php ENDPATH**/ ?>