<div class="col">
    <div class="row mt-5">
        <div class="col-4">
            <a href="datauser" class="btn btn-success h-100 w-100 d-flex justify-content-center align-items-center"> DATA <br>USER</a>
        </div>
        <div class="col-4">
            <a href="databarang" class="btn btn-success h-100 w-100 d-flex justify-content-center align-items-center py-4">DATA <br>BARANG</a>
        </div>
        <div class="col-4">
            <a href="barangmasuk" class="btn btn-success h-100 w-100 d-flex justify-content-center align-items-center py-4">BARANG <br>MASUK</a>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-4">
            <a href="datasupplier" class="btn btn-success h-100 w-100 d-flex justify-content-center align-items-center py-4">DATA <br>SUPPLIER</a>
        </div>
        <div class="col-4">
            <a href="barangkeluar" class="btn btn-success h-100 w-100 d-flex justify-content-center align-items-center py-4">BARANG <br>KELUAR</a>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\inven\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>