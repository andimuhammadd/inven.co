<div class="col">
    <div class="table-responsive">
        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th>Nomor</th>
                    <th>Nama Supplier</th>
                    <th>Alamat</th>
                    <th>Telepon</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $number = 1;
                ?>
                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($number); ?></td>
                    <td><?php echo e($supplier->nama); ?></td>
                    <td><?php echo e($supplier->alamat); ?></td>
                    <td><?php echo e($supplier->telepon); ?></td>
                    <td>
                        <?php echo $__env->make('component.supplier.modal_edit_supplier', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#modaledit<?php echo e($supplier->id); ?>">Edit</a>
                        <?php echo $__env->make('component.supplier.modal_hapus_supplier', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#modalHapus<?php echo e($supplier->id); ?>">Hapus</a>
                    </td>
                </tr>
                <?php
                $number++;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(count($suppliers) === 0): ?>
                <tr>
                    <td colspan="5">Data Supplier kosong</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>


    <?php echo $__env->make('component.supplier.modal_tambah_supplier', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAddSupplier">
        Tambah Supplier
    </button>
</div><?php /**PATH D:\laragon\www\inven\resources\views/pages/datasupplier.blade.php ENDPATH**/ ?>