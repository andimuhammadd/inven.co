<div id="modalContent">
    <form action="<?php echo e(route('barangkeluar.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
            <div class="mb-3">
                <label for="kode_barang" class="form-label">Kode Barang</label>
                <select class="form-control" id="id_data_barang" name="id_data_barang" required>
                    <option value="" disabled selected>Pilih Barang</option>
                    <?php if($databarangs->isEmpty()): ?>
                    <option value="" disabled>Data Barang tidak ada</option>
                    <?php else: ?>
                    <?php $__currentLoopData = $databarangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $databarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($databarang->id); ?>" data-id="<?php echo e($databarang->kode_barang); ?>"><?php echo e($databarang->kode_barang); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="nama_barang" class="form-label">Nama Barang</label>
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" required readonly>
            </div>

            <div class="mb-3">
                <label for="jumlah" class="form-label">Jumlah</label>
                <input type="number" class="form-control" id="jumlah" name="jumlah" required>
            </div>

            <input type="hidden" name="id_perusahaan" value="<?php echo e(Auth::user()->perusahaan_id); ?>">

            <script>
                // Menggunakan jQuery untuk menangani perubahan pada select box
                $(document).ready(function() {
                    $('#id_data_barang').on('change', function() {
                        var kodeBarang = $(this).find('option:selected').data('id');

                        // Cari data barang berdasarkan kode barang yang dipilih
                        var dataBarang = <?php echo json_encode($databarangs, 15, 512) ?>;

                        // Temukan data barang dengan kode barang yang dipilih
                        var selectedBarang = dataBarang.find(function(barang) {
                            return barang.kode_barang === kodeBarang;
                        });

                        // Jika data barang ditemukan, isi nama barang
                        if (selectedBarang) {
                            $('#nama_barang').val(selectedBarang.nama_barang);
                        } else {
                            // Jika data barang tidak ditemukan, kosongkan nama barang dan supplier
                            $('#nama_barang').val('');
                        }
                    });
                });
            </script>

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
    </form>
</div><?php /**PATH D:\laragon\www\inven\resources\views/component/barangkeluar/modal_keluarkanbarang.blade.php ENDPATH**/ ?>