<div class="col">
    <div class="table-responsive">
        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th>Nomor</th>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th>Jumlah</th>
                    <th>Tanggal Masuk</th>
                    <th>Hapus</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $number = 1;
                ?>
                <?php $__currentLoopData = $barangMasuks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangMasuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($number); ?></td>
                    <td><?php echo e($barangMasuk->databarang->kode_barang); ?></td>
                    <td><?php echo e($barangMasuk->databarang->nama_barang); ?></td>
                    <td><?php echo e($barangMasuk->jumlah); ?></td>
                    <td><?php echo e($barangMasuk->created_at); ?></td>
                    <td>
                        <?php echo $__env->make('component.barangmasuk.modalhapus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#ModalHapus<?php echo e($barangMasuk->id); ?>">
                            Hapus
                        </button>
                    </td>
                </tr>
                <?php
                $number++;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(count($barangMasuks) === 0): ?>
                <tr>
                    <td colspan="6">Data Transaksi Barang Masuk kosong</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Button trigger modal -->
    <button id="btnModal" type="button" class="btn btn-primary">Tambah Transaksi</button>

    <!-- Modal -->
    <?php echo $__env->make('component.barangmasuk.templateModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Modal -->

    <!-- Include jQuery library -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#btnModal').click(function() {
                // Menggunakan AJAX untuk memuat konten modal
                $.ajax({
                    url: "<?php echo e(route('barangmasuk.create')); ?>",
                    method: "GET",
                    dataType: "html",
                    success: function(response) {
                        $('#modalContent').html(response);

                        // Menampilkan modal setelah konten dimuat
                        var modal = new bootstrap.Modal(document.getElementById('modalAddBarangMasuk'));
                        modal.show();
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                    }
                });
            });
        });
    </script>


</div><?php /**PATH D:\laragon\www\inven\resources\views/pages/barangmasuk.blade.php ENDPATH**/ ?>