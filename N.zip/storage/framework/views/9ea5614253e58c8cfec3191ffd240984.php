<div class="col">
    <div class="table-responsive">
        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th>Nomor</th>
                    <th>Nama Satuan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $number = 1;
                ?>
                <?php $__currentLoopData = $satuanbarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($number); ?></td>
                    <td><?php echo e($satuan->nama_satuan); ?></td>
                    <td>
                        <?php echo $__env->make('component.satuan.modal_edit_satuan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#modaledit<?php echo e($satuan->id); ?>">Edit</a>

                        <?php echo $__env->make('component.satuan.modal_hapus_satuan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#modalhapus<?php echo e($satuan->id); ?>">Hapus</a>
                    </td>
                </tr>
                <?php
                $number++;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(count($satuanbarang) === 0): ?>
                <tr>
                    <td colspan="5">Data Satuan Barang kosong</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo $__env->make('component.satuan.modal_tambah_satuan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAddSsatuan">
        Tambah Satuan
    </button>
</div><?php /**PATH D:\laragon\www\inven\resources\views/pages/satuanbarang.blade.php ENDPATH**/ ?>