<!-- Modal Hapus Satuan -->
<div class="modal fade" id="modalhapus<?php echo e($satuan->id); ?>" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUserModalLabel">Form Hapus Satuan</h5>
                <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('satuanbarang.destroy', $satuan->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <h5 class="modal-title" id="editUserModalLabel">Hapus Satuan <?php echo e($satuan->nama_satuan); ?>?</h5>
                    <button type="submit" class="btn btn-primary">Hapus Satuan</button>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\inven\resources\views/component/satuan/modal_hapus_satuan.blade.php ENDPATH**/ ?>