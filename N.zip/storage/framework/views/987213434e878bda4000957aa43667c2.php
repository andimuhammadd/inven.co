<?php
use App\Models\User;

$perusahaan_id = Auth::user()->perusahaan_id;

$users = User::where('perusahaan_id', $perusahaan_id)->get();
?>
<div class="col">
    <div class="table-responsive">
        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th>Nomor</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Profile</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $number = 1; // Inisialisasi nomor awal
                ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user->id !== Auth::id()): ?>
                <tr>
                    <td><?php echo e($number); ?></td>
                    <td><?php echo e($user->nama); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->role); ?></td>
                    <td>
                        <img src="<?php echo e(asset('images/' . $user->foto_profile)); ?>" alt="Foto Profil" width="50" height="50">
                    </td>
                    <td>
                        <?php echo $__env->make('component.modal_edit_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#editUserModal<?php echo e($user->id); ?>">Edit</a>
                        <?php echo $__env->make('component.modal_hapus_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#modalHapusUser<?php echo e($user->id); ?>">Hapus</a>

                    </td>
                </tr>
                <?php
                $number++;
                ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(count($users) === 1): ?>
                <tr>
                    <td colspan="5">Data user kosong</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo $__env->make('component.modal_tambah_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Tambah User
    </button>

</div><?php /**PATH D:\laragon\www\inven\resources\views/pages/datauser.blade.php ENDPATH**/ ?>