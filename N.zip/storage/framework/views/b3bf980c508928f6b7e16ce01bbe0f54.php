<div class="col">
    <div class="table-responsive">
        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th>Nomor</th>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th>Jumlah</th>
                    <th>keterangan</th>
                    <th>Tanggal Keluar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $number = 1;
                ?>
                <?php $__currentLoopData = $barangKeluars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangKeluar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($number); ?></td>
                    <td><?php echo e($barangKeluar->databarang->kode_barang); ?></td>
                    <td><?php echo e($barangKeluar->databarang->nama_barang); ?></td>
                    <td><?php echo e($barangKeluar->jumlah); ?></td>
                    <td><?php echo e($barangKeluar->keterangan); ?></td>
                    <td><?php echo e($barangKeluar->created_at); ?></td>
                    <td>
                        <?php echo $__env->make('component.barangkeluar.modalhapus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#ModalHapus<?php echo e($barangKeluar->id); ?>">
                            Hapus
                        </button>
                    </td>
                </tr>
                <?php
                $number++;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(count($barangKeluars) === 0): ?>
                <tr>
                    <td colspan="6">Data Transaksi Barang keluar kosong</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <button id="btnModal2" type="button" class="btn btn-primary">Tambah Transaksi</button>

    <?php echo $__env->make('component.barangkeluar.templateModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#btnModal2').click(function() {
                // Menggunakan AJAX untuk memuat konten modal
                $.ajax({
                    url: "<?php echo e(route('barangkeluar.create')); ?>",
                    method: "GET",
                    dataType: "html",
                    success: function(response) {
                        $('#modalContent2').html(response);

                        // Menampilkan modal setelah konten dimuat
                        var modal = new bootstrap.Modal(document.getElementById('modalAddBarangKeluar'));
                        modal.show();
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                    }
                });
            });
        });
    </script>
</div><?php /**PATH D:\laragon\www\inven\resources\views/pages/barangkeluar.blade.php ENDPATH**/ ?>